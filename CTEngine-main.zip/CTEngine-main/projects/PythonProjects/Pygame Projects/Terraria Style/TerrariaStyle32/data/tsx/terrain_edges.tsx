<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="terrain_edges" tilewidth="32" tileheight="32" tilecount="20" columns="10">
 <image source="../../graphics/32bit/terrain_edges32.png" width="320" height="64"/>
 <wangsets>
  <wangset name="Roads" type="edge" tile="-1">
   <wangcolor name="Yellow" color="#ff0000" tile="-1" probability="1"/>
   <wangtile tileid="0" wangid="0,0,1,0,1,0,0,0"/>
   <wangtile tileid="1" wangid="0,0,0,0,1,0,1,0"/>
   <wangtile tileid="4" wangid="0,0,1,0,1,0,1,0"/>
   <wangtile tileid="5" wangid="1,0,0,0,1,0,0,0"/>
   <wangtile tileid="6" wangid="0,0,1,0,0,0,1,0"/>
   <wangtile tileid="7" wangid="1,0,1,0,1,0,1,0"/>
   <wangtile tileid="8" wangid="0,0,0,0,1,0,0,0"/>
   <wangtile tileid="9" wangid="0,0,0,0,0,0,1,0"/>
   <wangtile tileid="10" wangid="1,0,1,0,0,0,0,0"/>
   <wangtile tileid="11" wangid="1,0,0,0,0,0,1,0"/>
   <wangtile tileid="14" wangid="1,0,1,0,0,0,1,0"/>
   <wangtile tileid="15" wangid="1,0,1,0,1,0,0,0"/>
   <wangtile tileid="16" wangid="1,0,0,0,1,0,1,0"/>
   <wangtile tileid="18" wangid="1,0,0,0,0,0,0,0"/>
   <wangtile tileid="19" wangid="0,0,1,0,0,0,0,0"/>
  </wangset>
 </wangsets>
</tileset>
