#include <iostream>

int main ()
{
    
}